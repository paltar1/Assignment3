import {Book} from './bookInfo';

export const MYBOOK: Book[] = [
    {bookName: "Mostly Dead Things", bookAuthor: "Kristen Arnett", bookGenere: "Humour,Domestic Fiction", bookPublished:2019, picture: "assets/images/pic1.jpg"},
    {bookName: "Agni Ki Udaan", bookAuthor: "A. P. J. Abdul Kalam, Arun Tiwari", bookGenere: "Autobiography, Biography", bookPublished: 1999, picture: "assets/images/pic2.jpg"},
    {bookName: "2 States: The Story of My Marriage", bookAuthor: "Chetan Bhagat", bookGenere: "Romance novel, Fiction", bookPublished:  2009, picture: "assets/images/pic3.jpg"},
    {bookName: "Chandrakanta", bookAuthor: "Devaki Nandan Khatri", bookGenere: "Fantasy Fiction", bookPublished: 1888, picture: "assets/images/pic4.jpg"},
]