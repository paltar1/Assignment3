import { Component, OnInit } from '@angular/core';
import { Paltar } from '../paltar';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  currStudent: Paltar = {
    Stunum: 991504994, Stuname: "Taranveer Pal",
    Stulogin: "paltar", Stucampus: "Trafalgar", 
  Stutitle: "Paltar Assignment3"
  }
  constructor() { }

  ngOnInit() {
  }

}
