export class Book {
    bookName: string;
    bookAuthor: string;
    bookGenere: string;
    bookPublished: number;
    picture: string;
}