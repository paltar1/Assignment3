import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { paltarComponent } from './paltar.component';

describe('PaltarComponent', () => {
  let component: paltarComponent;
  let fixture: ComponentFixture<paltarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ paltarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(paltarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});



