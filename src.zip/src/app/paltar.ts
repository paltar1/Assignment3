export class Paltar {
    Stunum: number;
    Stuname: string;
    Stulogin: string;
   Stucampus: string;
   Stutitle: string;
}
