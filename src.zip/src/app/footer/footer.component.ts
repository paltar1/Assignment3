import { Component, OnInit } from '@angular/core';
import { Paltar } from "../paltar"
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  currStudent: Paltar = {
    Stunum: 991504994, Stuname: "Taranveer Pal",
    Stulogin: "paltar", Stucampus: "Trafalgar", 
    Stutitle: "Paltar Assignment3"
  }
  constructor() { }

  ngOnInit() {
  }

}
